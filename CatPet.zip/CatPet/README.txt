CREATE DATE		: 22/12/2021
AUTHOR			: CHIEW HONG KUANG
PROJECT DESCRIPTION	:

This is an Desktop Pet Python Application.

A pretty kitty will appear on your screen!

Right click the kitty for more option!